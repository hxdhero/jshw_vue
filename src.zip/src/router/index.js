import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

import Navbar from 'components/Navbar'
import Count from 'components/Count'

export default new Router({
  routes: [
    {
      path: '/',
      components: {
        content: Count,
        nav: Navbar
      }

    }
  ]
})
